# PiezoElectric-Sensor-Library-For-Proteus

Hello Guys, As you know piezo sensor Library is not available in proteus, so i designed this library to help everyone on request of one of my subscriber on youtube. Link to download this library is now also available. Piezo sensor simulation in proteus is now possible with the help of this library.

* <b> Version 1.0 (Stable release) </b>

<img src="https://1.bp.blogspot.com/-SOqiRLNM7V8/YFbEswh6D3I/AAAAAAAAaWg/JbIZnoVPM6gPvDaBvlpQVLT9mwWPqrIVwCLcBGAsYHQ/s16000/Piezo_Sensor_proteus.PNG" />
