# Proteus-library-8.0-
These are some libraries i have created for my PCB design works.
Most of them are missing the simulation model though!! (since i could not find any guide on that. Would really appretiate if some one could shed some light on that.)

Just download and put them in the Library folder of proteus and u are good to go.
